#include "PicturesModel.h"

using namespace Page;

void PicturesModel::Init()
{
	
}

void PicturesModel::DeInit()
{
	
}
